use std::cell::RefCell;
use std::collections::VecDeque;
use std::collections::HashSet;
use std::rc::Rc;
use crate::entity::Entity;
use crate::command::Command;

pub struct BattleEngine {
    entities: Vec<Rc<RefCell<Entity>>>,
    action_queue: VecDeque<Box<dyn Command>>,
    round: u32,
    is_running: bool,
}

impl BattleEngine {
    pub fn new() -> Self {
        BattleEngine {
            entities: Vec::new(),
            action_queue: VecDeque::new(),
            round: 0,
            is_running: true,
        }
    }
    
    pub fn add_entity(&mut self, entity: Entity) -> Rc<RefCell<Entity>> {
        let rc_entity = Rc::new(RefCell::new(entity));
        self.entities.push(rc_entity.clone());
        rc_entity
    }
    
    pub fn plan_action(&mut self, command: Box<dyn Command>) {
        println!("📋 Запланировано действие: {}", command.description());
        self.action_queue.push_back(command);
    }
    
    fn pre_process(&mut self) {
        println!("\n--- Фаза пред-обработки (Раунд {}) ---", self.round);
        
        for entity_rc in &self.entities {
            let entity = entity_rc.borrow();
            if entity.is_dead() {
                continue;
            }
            
            println!("Обработка эффектов для {}", entity.name);
            let effects = entity.effects.borrow();
            for effect in effects.iter() {
                println!("  Эффект: {}", effect.name());
            }
        }
    }
    
    fn process_effects(&mut self) {
        println!("\n--- Фаза эффектов (Раунд {}) ---", self.round);
        
        let entities_to_process: Vec<_> = self.entities
            .iter()
            .filter(|e| !e.borrow().is_dead())
            .cloned()
            .collect();
        
        for entity_rc in entities_to_process {
            let entity = entity_rc.borrow();
            println!("Эффекты для {}:", entity.name);
            
            let mut effects_to_apply = Vec::new();
            {
                let effects = entity.effects.borrow();
                for effect in effects.iter() {
                    effects_to_apply.push((effect.name().to_string(), effect.is_expired()));
                }
            }
            
            let mut effects = entity.effects.borrow_mut();
            
            // Применяем эффекты
            for effect in effects.iter_mut() {
                effect.apply(&entity);
            }
            
            // Уменьшаем длительность
            for effect in effects.iter_mut() {
                effect.tick();
            }
        }
    }
    
    fn cleanup_expired_effects(&mut self) {
        println!("\n--- Очистка просроченных эффектов ---");
        
        for entity_rc in &self.entities {
            let entity = entity_rc.borrow_mut();
            if entity.is_dead() {
                continue;
            }
            
            let mut effects = entity.effects.borrow_mut();
            let before_count = effects.len();
            effects.retain(|effect| !effect.is_expired());
            let removed_count = before_count - effects.len();
            
            if removed_count > 0 {
                println!("  У {} удалено {} просроченных эффектов", entity.name, removed_count);
            }
        }
    }
    
    fn execute_actions(&mut self) {
        println!("\n--- Исполнение команд (Раунд {}) ---", self.round);
        
        while let Some(command) = self.action_queue.pop_front() {
            println!("Выполняется: {}", command.description());
            command.execute();
            println!("---");
        }
    }
    
    fn post_process(&mut self) {
        println!("\n--- Фаза пост-обработки (Раунд {}) ---", self.round);
        
        let mut dead_entities = Vec::new();
        
        for entity_rc in &self.entities {
            let entity = entity_rc.borrow();
            if entity.is_dead() || entity.stats.borrow().hp <= 0 {
                dead_entities.push(entity_rc.clone());
            }
        }
        
        for dead in dead_entities {
            let mut dead_entity = dead.borrow_mut();
            if dead_entity.is_alive {
                dead_entity.die();
            }
        }
    }
    
    fn check_victory(&self) -> Option<String> {
        let mut alive_factions = HashSet::new();
        
        for entity_rc in &self.entities {
            let entity = entity_rc.borrow();
            if !entity.is_dead() && entity.stats.borrow().hp > 0 {
                alive_factions.insert(entity.faction.clone());
            }
        }
        
        if alive_factions.len() == 1 {
            Some(alive_factions.into_iter().next().unwrap())
        } else if alive_factions.is_empty() {
            Some("Ничья".to_string())
        } else {
            None
        }
    }
    
    pub fn run_round(&mut self) -> bool {
        self.round += 1;
        println!("\n{}", "=".repeat(50));
        println!("НАЧАЛО РАУНДА {}", self.round);
        println!("{}", "=".repeat(50));
        
        self.pre_process();
        self.process_effects();
        self.execute_actions();
        self.post_process();
        self.cleanup_expired_effects();
        
        if let Some(winner) = self.check_victory() {
            println!("\n🏆 ПОБЕДА! Победитель: {} 🏆", winner);
            self.is_running = false;
            false
        } else {
            println!("\n--- Конец раунда {} ---", self.round);
            self.print_status();
            true
        }
    }
    
    pub fn print_status(&self) {
        println!("\n=== ТЕКУЩЕЕ СОСТОЯНИЕ БИТВЫ ===");
        for entity_rc in &self.entities {
            let entity = entity_rc.borrow();
            if !entity.is_dead() {
                let stats = entity.stats.borrow();
                println!("{} [{}]: HP {}/{}, Mana {}/{}, Сила {}, Защита {}", 
                         entity.name, entity.faction, stats.hp, stats.max_hp, 
                         stats.mana, stats.max_mana, stats.strength, stats.defense);
                
                let effects = entity.effects.borrow();
                if !effects.is_empty() {
                    println!("  Эффекты: {}", effects.iter().map(|e| e.name()).collect::<Vec<_>>().join(", "));
                }
            } else {
                println!("{} [{}]: МЕРТВ", entity.name, entity.faction);
            }
        }
        println!("=============================\n");
    }
    
    pub fn run_battle(&mut self, max_rounds: u32) {
        self.print_status();
        
        for _ in 0..max_rounds {
            if !self.run_round() {
                break;
            }
        }
        
        if self.is_running {
            println!("\n⚠️ Битва завершена по лимиту раундов!");
            self.print_status();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::command::{AttackCommand};
    use crate::entity::Entity;

    #[test]
    fn test_battle_engine() {
        let mut engine = BattleEngine::new();
        
        let hero = engine.add_entity(Entity::new("Герой", "Свет", 100, 50, 20, 10));
        let villain = engine.add_entity(Entity::new("Злодей", "Тьма", 100, 30, 15, 8));
        
        engine.plan_action(Box::new(AttackCommand::new(hero.clone(), villain.clone(), 15)));
        engine.plan_action(Box::new(AttackCommand::new(villain.clone(), hero.clone(), 10)));
        
        engine.run_round();
        
        let hero_hp = hero.borrow().stats.borrow().hp;
        let villain_hp = villain.borrow().stats.borrow().hp;
        
        assert!(hero_hp < 100);
        assert!(villain_hp < 100);
    }
}