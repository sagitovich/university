use std::cell::RefCell;
use std::fmt::Debug;
use crate::effect::Effect;

#[derive(Debug, Clone)]
pub struct Stats {
    pub max_hp: i32,
    pub hp: i32,
    pub max_mana: i32,
    pub mana: i32,
    pub strength: i32,
    pub defense: i32,
}

impl Stats {
    pub(crate) fn new(max_hp: i32, max_mana: i32, strength: i32, defense: i32) -> Self {
        Stats {
            max_hp,
            hp: max_hp,
            max_mana,
            mana: max_mana,
            strength,
            defense,
        }
    }

    pub(crate) fn take_damage(&mut self, damage: i32) {
        let actual_damage = (damage - self.defense).max(1);
        self.hp = (self.hp - actual_damage).max(0);
        println!("  Получено {} урона ({} - защита {}), HP: {}", 
                 actual_damage, damage, self.defense, self.hp);
    }

    pub(crate) fn heal(&mut self, amount: i32) {
        self.hp = (self.hp + amount).min(self.max_hp);
        println!("  Восстановлено {} HP, текущее HP: {}", amount, self.hp);
    }

    pub(crate) fn use_mana(&mut self, amount: i32) -> bool {
        if self.mana >= amount {
            self.mana -= amount;
            true
        } else {
            false
        }
    }
}

pub struct Entity {
    pub name: String,
    pub faction: String,
    pub stats: RefCell<Stats>,
    pub effects: RefCell<Vec<Box<dyn Effect>>>,
    pub is_alive: bool,
}

impl Entity {
    pub fn new(name: &str, faction: &str, max_hp: i32, max_mana: i32, strength: i32, defense: i32) -> Self {
        Entity {
            name: name.to_string(),
            faction: faction.to_string(),
            stats: RefCell::new(Stats::new(max_hp, max_mana, strength, defense)),
            effects: RefCell::new(Vec::new()),
            is_alive: true,
        }
    }

    pub fn add_effect(&self, effect: Box<dyn Effect>) {
        self.effects.borrow_mut().push(effect);
        println!("  {} получил новый эффект", self.name);
    }

    pub fn is_dead(&self) -> bool {
        !self.is_alive || self.stats.borrow().hp <= 0
    }

    pub fn die(&mut self) {
        self.is_alive = false;
        println!("💀 {} погиб!", self.name);
    }
}

impl Debug for Entity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let stats = self.stats.borrow();
        write!(
            f,
            "Entity {{ name: {}, faction: {}, HP: {}/{}, Mana: {}/{}, alive: {} }}",
            self.name, self.faction, stats.hp, stats.max_hp, stats.mana, stats.max_mana, self.is_alive
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::effect::Poison;
    use std::rc::Rc;

    #[test]
    fn test_entity_creation() {
        let entity = Entity::new("Тест", "Нейтрал", 100, 50, 10, 5);
        let stats = entity.stats.borrow();
        assert_eq!(stats.hp, 100);
        assert_eq!(stats.mana, 50);
        assert_eq!(entity.is_alive, true);
    }
}