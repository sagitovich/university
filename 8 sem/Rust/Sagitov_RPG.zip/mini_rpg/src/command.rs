use std::cell::RefCell;
use std::rc::Rc;
use std::fmt::Debug;
use crate::entity::Entity;
use crate::effect::Burning;

pub trait Command: Debug {
    fn execute(&self);
    fn description(&self) -> String;
}

#[derive(Debug)]
pub struct AttackCommand {
    attacker: Rc<RefCell<Entity>>,
    target: Rc<RefCell<Entity>>,
    damage: i32,
}

impl AttackCommand {
    pub fn new(attacker: Rc<RefCell<Entity>>, target: Rc<RefCell<Entity>>, damage: i32) -> Self {
        AttackCommand { attacker, target, damage }
    }
}

impl Command for AttackCommand {
    fn execute(&self) {
        // check: атакующий и цель - один объект
        if Rc::ptr_eq(&self.attacker, &self.target) {
            println!("  Нельзя атаковать самого себя!");
            return;
        }
        
        let attacker_ref = self.attacker.borrow_mut();
        
        if attacker_ref.is_dead() {
            println!("  {} мертв и не может атаковать!", attacker_ref.name);
            return;
        }
        
        let mut target_ref = self.target.borrow_mut();
        
        if target_ref.is_dead() {
            println!("  {} уже мертв!", target_ref.name);
            return;
        }
        
        let total_damage = self.damage + attacker_ref.stats.borrow().strength;
        println!("⚔️ {} атакует {} и наносит {} урона!", 
                 attacker_ref.name, target_ref.name, total_damage);
        
        target_ref.stats.borrow_mut().take_damage(total_damage);
        
        if target_ref.stats.borrow().hp <= 0 {
            target_ref.die();
        }
    }
    
    fn description(&self) -> String {
        format!("Атака {} на {}", self.attacker.borrow().name, self.target.borrow().name)
    }
}

#[derive(Debug)]
pub struct HealCommand {
    caster: Rc<RefCell<Entity>>,
    target: Rc<RefCell<Entity>>,
    amount: i32,
}

impl HealCommand {
    pub fn new(caster: Rc<RefCell<Entity>>, target: Rc<RefCell<Entity>>, amount: i32) -> Self {
        HealCommand { caster, target, amount }
    }
}

impl Command for HealCommand {
    fn execute(&self) {
        let same_target = Rc::ptr_eq(&self.caster, &self.target);
        
        let caster_ref = self.caster.borrow_mut();
        
        if caster_ref.is_dead() {
            println!("  {} мертв и не может лечить!", caster_ref.name);
            return;
        }
        
        if !caster_ref.stats.borrow_mut().use_mana(10) {
            println!("  У {} недостаточно маны для лечения!", caster_ref.name);
            return;
        }
        
        if same_target {
            println!("💚 {} лечит себя на {} HP!", caster_ref.name, self.amount);
            caster_ref.stats.borrow_mut().heal(self.amount);
        } else {
            let target_ref = self.target.borrow_mut();
            if target_ref.is_dead() {
                println!("  {} мертв, лечить бесполезно!", target_ref.name);
                return;
            }
            println!("💚 {} лечит {} на {} HP!", caster_ref.name, target_ref.name, self.amount);
            target_ref.stats.borrow_mut().heal(self.amount);
        }
    }
    
    fn description(&self) -> String {
        format!("Лечение {} от {}", self.target.borrow().name, self.caster.borrow().name)
    }
}

#[derive(Debug)]
pub struct FireSpellCommand {
    caster: Rc<RefCell<Entity>>,
    target: Rc<RefCell<Entity>>,
    damage: i32,
    burn_duration: u32,
}

impl FireSpellCommand {
    pub fn new(caster: Rc<RefCell<Entity>>, target: Rc<RefCell<Entity>>, damage: i32, burn_duration: u32) -> Self {
        FireSpellCommand { caster, target, damage, burn_duration }
    }
}

impl Command for FireSpellCommand {
    fn execute(&self) {
        if Rc::ptr_eq(&self.caster, &self.target) {
            println!("  Нельзя кастовать заклинание на себя!");
            return;
        }
        
        let caster_ref = self.caster.borrow_mut();
        
        if caster_ref.is_dead() {
            println!("  {} мертв и не может колдовать!", caster_ref.name);
            return;
        }
        
        if !caster_ref.stats.borrow_mut().use_mana(15) {
            println!("  У {} недостаточно маны для огненного заклинания!", caster_ref.name);
            return;
        }
        
        let mut target_ref = self.target.borrow_mut();
        
        if target_ref.is_dead() {
            println!("  {} уже мертв!", target_ref.name);
            return;
        }
        
        println!("🔥 {} кастует Огненный Шар в {} и наносит {} урона!", 
                 caster_ref.name, target_ref.name, self.damage);
        
        target_ref.stats.borrow_mut().take_damage(self.damage);
        
        if target_ref.stats.borrow().hp > 0 {
            let burning = Box::new(Burning::new(self.burn_duration, 5));
            drop(target_ref);
            self.target.borrow().add_effect(burning);
        } else {
            target_ref.die();
        }
    }
    
    fn description(&self) -> String {
        format!("Огненный шар от {} в {}", self.caster.borrow().name, self.target.borrow().name)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::rc::Rc;
    use std::cell::RefCell;
    use crate::entity::Entity;

    #[test]
    fn test_attack_command() {
        let attacker = Rc::new(RefCell::new(Entity::new("Атакующий", "Свет", 100, 0, 20, 0)));
        let target = Rc::new(RefCell::new(Entity::new("Цель", "Тьма", 100, 0, 0, 0)));
        
        let attack = AttackCommand::new(attacker, target.clone(), 10);
        attack.execute();
        
        assert_eq!(target.borrow().stats.borrow().hp, 70);
    }
    
    #[test]
    fn test_heal_command() {
        let caster = Rc::new(RefCell::new(Entity::new("Лекарь", "Свет", 100, 50, 0, 0)));
        let target = Rc::new(RefCell::new(Entity::new("Пациент", "Свет", 100, 0, 0, 0)));
        
        target.borrow_mut().stats.borrow_mut().hp = 50;
        
        let heal = HealCommand::new(caster, target.clone(), 30);
        heal.execute();
        
        assert_eq!(target.borrow().stats.borrow().hp, 80);
    }
    
    #[test]
    fn test_self_heal_command() {
        let caster = Rc::new(RefCell::new(Entity::new("Лекарь", "Свет", 100, 50, 0, 0)));
        caster.borrow_mut().stats.borrow_mut().hp = 50;
        
        let heal = HealCommand::new(caster.clone(), caster.clone(), 30);
        heal.execute();
        
        assert_eq!(caster.borrow().stats.borrow().hp, 80);
        assert_eq!(caster.borrow().stats.borrow().mana, 40);
    }
}