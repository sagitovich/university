mod entity;
mod effect;
mod command;
mod engine;

use entity::Entity;
use effect::{Shield, Poison, Regeneration};
use command::{AttackCommand, HealCommand, FireSpellCommand};
use engine::BattleEngine;

fn main() {
    println!("🎮 ЗАПУСК МИНИ-RPG 🎮\n");
    
    let mut engine = BattleEngine::new();
    
    // Создаем игроков
    let hero = engine.add_entity(Entity::new("Герой", "Свет", 100, 50, 20, 10));
    let villain = engine.add_entity(Entity::new("Злодей", "Тьма", 80, 30, 18, 8));
    let monster = engine.add_entity(Entity::new("Орк", "Тьма", 60, 0, 15, 5));
    
    // Добавляем начальные эффекты для теста
    hero.borrow().add_effect(Box::new(Shield::new(3, 5)));
    hero.borrow().add_effect(Box::new(Shield::new(3, 5)));
    hero.borrow().add_effect(Box::new(Regeneration::new(3, 5)));
    villain.borrow().add_effect(Box::new(Poison::new(2, 8)));
    
    // Планируем действия для первого раунда
    println!("📝 Планирование действий...\n");
    
    engine.plan_action(Box::new(AttackCommand::new(
        hero.clone(), villain.clone(), 15
    )));
    
    engine.plan_action(Box::new(FireSpellCommand::new(
        hero.clone(), monster.clone(), 20, 3
    )));
    
    engine.plan_action(Box::new(HealCommand::new(
        hero.clone(), hero.clone(), 15
    )));
    
    engine.plan_action(Box::new(AttackCommand::new(
        villain.clone(), hero.clone(), 12
    )));
    
    engine.plan_action(Box::new(AttackCommand::new(
        monster.clone(), hero.clone(), 10
    )));
    
    // Запускаем битву на 5 раундов
    engine.run_battle(5);
    
    println!("\n🎮 ИГРА ЗАВЕРШЕНА 🎮");
}