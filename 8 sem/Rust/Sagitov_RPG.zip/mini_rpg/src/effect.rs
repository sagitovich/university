use std::fmt::Debug;
use crate::entity::Entity;

pub trait Effect: Debug {
    fn apply(&mut self, target: &Entity);
    fn tick(&mut self);
    fn is_expired(&self) -> bool;
    fn name(&self) -> &str;
}

#[derive(Debug)]
pub struct Poison {
    duration: u32,
    damage: i32,
}

impl Poison {
    pub fn new(duration: u32, damage: i32) -> Self {
        Poison { duration, damage }
    }
}

impl Effect for Poison {
    fn apply(&mut self, target: &Entity) {
        if self.duration > 0 {
            println!("  ☠️ Яд наносит {} урона {} (осталось {} ходов)", 
                     self.damage, target.name, self.duration);
            target.stats.borrow_mut().take_damage(self.damage);
        }
    }

    fn tick(&mut self) {
        if self.duration > 0 {
            self.duration -= 1;
        }
    }

    fn is_expired(&self) -> bool {
        self.duration == 0
    }

    fn name(&self) -> &str {
        "Отравление"
    }
}

#[derive(Debug)]
pub struct Burning {
    duration: u32,
    damage: i32,
}

impl Burning {
    pub fn new(duration: u32, damage: i32) -> Self {
        Burning { duration, damage }
    }
}

impl Effect for Burning {
    fn apply(&mut self, target: &Entity) {
        if self.duration > 0 {
            println!("  🔥 Горение наносит {} урона {} (осталось {} ходов)", 
                     self.damage, target.name, self.duration);
            target.stats.borrow_mut().take_damage(self.damage);
        }
    }

    fn tick(&mut self) {
        if self.duration > 0 {
            self.duration -= 1;
        }
    }

    fn is_expired(&self) -> bool {
        self.duration == 0
    }

    fn name(&self) -> &str {
        "Горение"
    }
}

#[derive(Debug)]
pub struct Shield {
    duration: u32,
    armor_bonus: i32,
}

impl Shield {
    pub fn new(duration: u32, armor_bonus: i32) -> Self {
        Shield { duration, armor_bonus }
    }
}

impl Effect for Shield {
    fn apply(&mut self, target: &Entity) {
        if self.duration > 0 {
            println!("  🛡️ Щит действует на {} (осталось {} ходов), защита +{}", 
                     target.name, self.duration, self.armor_bonus);
            // В реальной игре здесь нужно временно увеличить защиту
            // Для простоты просто выводим сообщение
        }
    }

    fn tick(&mut self) {
        if self.duration > 0 {
            self.duration -= 1;
        }
    }

    fn is_expired(&self) -> bool {
        self.duration == 0
    }

    fn name(&self) -> &str {
        "Щит"
    }
}

#[derive(Debug)]
pub struct Regeneration {
    duration: u32,
    heal_amount: i32,
}

impl Regeneration {
    pub fn new(duration: u32, heal_amount: i32) -> Self {
        Regeneration { duration, heal_amount }
    }
}

impl Effect for Regeneration {
    fn apply(&mut self, target: &Entity) {
        if self.duration > 0 {
            println!("  💚 Регенерация восстанавливает {} HP {} (осталось {} ходов)", 
                     self.heal_amount, target.name, self.duration);
            target.stats.borrow_mut().heal(self.heal_amount);
        }
    }

    fn tick(&mut self) {
        if self.duration > 0 {
            self.duration -= 1;
        }
    }

    fn is_expired(&self) -> bool {
        self.duration == 0
    }

    fn name(&self) -> &str {
        "Регенерация"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entity::Entity;

    #[test]
    fn test_poison_effect() {
        let entity = Entity::new("Тест", "Нейтрал", 100, 0, 0, 0);
        let mut poison = Poison::new(3, 10);
        
        poison.apply(&entity);
        assert_eq!(entity.stats.borrow().hp, 90);
        
        poison.tick();
        assert_eq!(poison.duration, 2);
        assert!(!poison.is_expired());
        
        poison.apply(&entity);
        assert_eq!(entity.stats.borrow().hp, 80);
        
        poison.tick();
        poison.tick();
        assert!(poison.is_expired());
    }
}